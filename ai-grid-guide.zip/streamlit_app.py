import streamlit as st
from src.openai_client import analyze_image, generate_speech
from src.prompts import MODES, build_prompt
import os
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="AI ช่วยเล่นเกม",
    page_icon="🎮",
    layout="centered"
)

st.markdown("""
<style>
    .stApp {
        max-width: 640px;
        margin: 0 auto;
    }
    .analysis-result {
        background: #111;
        color: #0f0;
        padding: 12px;
        border-radius: 8px;
        font-family: monospace;
        white-space: pre-wrap;
        margin-top: 1rem;
    }
    .stButton button {
        width: 100%;
    }
    @media (max-width: 640px) {
        .block-container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
    }
</style>
""", unsafe_allow_html=True)

if 'analysis_result' not in st.session_state:
    st.session_state['analysis_result'] = None
if 'captured_image' not in st.session_state:
    st.session_state['captured_image'] = None
if 'last_photo_id' not in st.session_state:
    st.session_state['last_photo_id'] = None

with st.sidebar:
    st.header("⚙️")

    default_key = os.getenv('OPENAI_API_KEY', '')
    api_key = st.text_input(
        "API Key",
        value=default_key,
        type="password",
        placeholder="sk-...",
        key="api_key_input"
    )

    mode = st.selectbox(
        "Mode",
        list(MODES.keys()),
        index=0,
        key="mode_select"
    )

    st.markdown("---")
    st.caption("AI ช่วยเล่นเกม")

st.title("🎮 AI ช่วยเล่นเกม")

camera_photo = st.camera_input("📸 ถ่ายภาพกระดาน", key="camera")

if camera_photo:
    photo_id = id(camera_photo)
    if st.session_state.get('last_photo_id') != photo_id:
        st.session_state['last_photo_id'] = photo_id
        st.session_state['captured_image'] = camera_photo.getvalue()

    st.image(camera_photo, width='stretch')

col1, col2 = st.columns(2)

with col1:
    analyze_clicked = st.button(
        "🎯 วิเคราะห์",
        type="primary",
        width='stretch',
        disabled=not (api_key and st.session_state.get('captured_image'))
    )

with col2:
    speak_clicked = st.button(
        "🔊 อ่านออกเสียง",
        width='stretch',
        disabled=not st.session_state.get('analysis_result')
    )

if analyze_clicked:
    with st.spinner("กำลังวิเคราะห์..."):
        try:
            prompt = build_prompt(mode)
            result = analyze_image(
                st.session_state['captured_image'],
                prompt,
                api_key
            )
            st.session_state['analysis_result'] = result
            st.success("✓")
        except Exception as e:
            st.error(f"ข้อผิดพลาด: {str(e)}")

if speak_clicked:
    with st.spinner("กำลังสร้างเสียง..."):
        try:
            audio_bytes = generate_speech(
                st.session_state['analysis_result'],
                api_key
            )
            st.audio(audio_bytes, format="audio/mpeg")
        except Exception as e:
            st.error(f"ข้อผิดพลาดเสียง: {str(e)}")

if st.session_state.get('analysis_result'):
    st.markdown(
        f'<div class="analysis-result">{st.session_state["analysis_result"]}</div>',
        unsafe_allow_html=True
    )
